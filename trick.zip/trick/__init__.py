from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)
import sys
import os
sys.path.append(os.getcwd() + "/trick.zip/trick")

import _sim_services
from sim_services import *

# create "all_cvars" to hold all global/static vars
all_cvars = new_cvar_list()
combine_cvars(all_cvars, cvar)
cvar = None

# /home/carey/trick_projects/SIM_bounce/S_source.hh
import _m2884835c339feeb905bf741895e42c51
combine_cvars(all_cvars, cvar)
cvar = None

# /home/carey/trick_projects/SIM_bounce/models/ball/include/ball.h
import _m58dc65aa26bee78327919cb9ff293147
combine_cvars(all_cvars, cvar)
cvar = None

# /home/carey/trick_projects/SIM_bounce/S_source.hh
from m2884835c339feeb905bf741895e42c51 import *
# /home/carey/trick_projects/SIM_bounce/models/ball/include/ball.h
from m58dc65aa26bee78327919cb9ff293147 import *

# S_source.hh
import _m2884835c339feeb905bf741895e42c51
from m2884835c339feeb905bf741895e42c51 import *

import _top
import top

import _swig_double
import swig_double

import _swig_int
import swig_int

import _swig_ref
import swig_ref

from shortcuts import *

from exception import *

cvar = all_cvars

