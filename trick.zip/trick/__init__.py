from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)
import sys
import os
sys.path.append(os.getcwd() + "/trick.zip/trick")

import _sim_services
from sim_services import *

# create "all_cvars" to hold all global/static vars
all_cvars = new_cvar_list()
combine_cvars(all_cvars, cvar)
cvar = None

# /home/carey/dev/trick_projects/SIM_bounce/S_source.hh
import _m3760e49f8f4ec3d51efb758e23c1288f
combine_cvars(all_cvars, cvar)
cvar = None

# /home/carey/dev/trick_projects/SIM_bounce/models/ball/include/ball.h
import _ma4296b76138a58d5856627d1da568668
combine_cvars(all_cvars, cvar)
cvar = None

# /home/carey/dev/trick_projects/SIM_bounce/S_source.hh
from m3760e49f8f4ec3d51efb758e23c1288f import *
# /home/carey/dev/trick_projects/SIM_bounce/models/ball/include/ball.h
from ma4296b76138a58d5856627d1da568668 import *

# S_source.hh
import _m3760e49f8f4ec3d51efb758e23c1288f
from m3760e49f8f4ec3d51efb758e23c1288f import *

import _top
import top

import _swig_double
import swig_double

import _swig_int
import swig_int

import _swig_ref
import swig_ref

from shortcuts import *

from exception import *

cvar = all_cvars

